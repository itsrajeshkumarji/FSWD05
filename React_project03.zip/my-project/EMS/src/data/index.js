const employeesData = [
  {
    id: 1,
    firstName: 'Rajesh',
    lastName: 'Kumar',
    email: 'rajesh@example.com',
    salary: '95000',
    date: '2019-04-11'
  },
  {
    id: 2,
    firstName: 'Arun',
    lastName: 'singh',
    email: 'arun@example.com',
    salary: '80000',
    date: '2019-04-17'
  },
  {
    id: 3,
    firstName: 'Akash',
    lastName: 'Bharti',
    email: 'akash@example.com',
    salary: '79000',
    date: '2019-05-01'
  },
  {
    id: 4,
    firstName: 'Suraj',
    lastName: 'Rawat',
    email: 'Suraj@example.com',
    salary: '56000',
    date: '2019-05-03'
  },
  {
    id: 5,
    firstName: 'Amar',
    lastName: 'deep',
    email: 'amar@example.com',
    salary: '65000',
    date: '2019-06-13'
  },
  {
    id: 6,
    firstName: 'Biplab',
    lastName: 'sharma',
    email: 'biplab@example.com',
    salary: '120000',
    date: '2019-07-30'
  },
  {
    id: 7,
    firstName: 'Jassi',
    lastName: 'Singh',
    email: 'jassi@example.com',
    salary: '90000',
    date: '2019-08-15'
  },
  {
    id: 8,
    firstName: 'Rutuja',
    lastName: 'mali',
    email: 'rutuja@example.com',
    salary: '60000',
    date: '2019-10-10'
  },
  {
    id: 9,
    firstName: 'Shivam',
    lastName: 'Soni',
    email: 'Shivam@example.com',
    salary: '71000',
    date: '2019-10-15'
  },
  {
    id: 10,
    firstName: 'Abhay',
    lastName: 'dwivedi',
    email: 'abhay@example.com',
    salary: '110000',
    date: '2020-01-15'
  },
  {
    id: 11,
    firstName: '',
    lastName:'',
    email: '',
    salary: '',
    date: ''
  }
];

export { employeesData };
